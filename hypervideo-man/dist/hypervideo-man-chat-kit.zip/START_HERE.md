# HyperVideo Man chat kit

Paste-and-upload files for chat platforms that take instructions plus knowledge files.

| Platform | Instructions field | Knowledge |
|---|---|---|
| Claude Project | instructions/02_Custom_Instructions.md (description: 01_Project_Description.md) | all files in knowledge/ |
| ChatGPT Custom GPT | instructions/02b_ChatGPT_Instructions.md (every field: GPT_CONFIG.md) | all files in knowledge/ |
| ChatGPT Project | instructions/02b_ChatGPT_Instructions.md | all files in knowledge/ |
| Microsoft 365 Copilot agent | instructions/02b_ChatGPT_Instructions.md | all files in knowledge/ |

Step-by-step guides for each platform are in setup/.
